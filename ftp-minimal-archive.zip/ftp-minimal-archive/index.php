<?php
/*
EMAF205 FTP MINIMAL ARCHIVE V1.2 COMPAT
Upload only this index.php into any folder. Optional: page.txt + project.txt.
Compatible style: avoids PHP 8-only syntax/functions for older shared hosting.
*/
$VERSION = 'EMAF205 FTP MINIMAL ARCHIVE V1.2 COMPAT';
$ROOT = dirname(__FILE__);

function ea_starts($s, $prefix) { return substr($s, 0, strlen($prefix)) === $prefix; }
function ea_contains($s, $needle) { return $needle === '' || strpos($s, $needle) !== false; }
function ea_trim($v) { return trim((string)$v); }
function ea_escape($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function ea_bool($v) { $v = strtolower(trim((string)$v)); return in_array($v, array('1','true','yes','y','on'), true); }
function ea_clean_line($line) { $line = trim((string)$line); if ($line === '' || substr($line,0,1) === '#') return ''; return $line; }
function ea_safe_slug($name) { return trim(str_replace(array("\0", '/', '\\'), '', (string)$name)); }

function ea_human_title($name) {
    $name = preg_replace('/\.[a-z0-9]{1,8}$/i', '', (string)$name);
    $name = str_replace(array('-', '_', '.'), ' ', $name);
    $name = preg_replace('/\s+/', ' ', trim($name));
    if ($name === '') return 'Archive';
    return ucwords(strtolower($name));
}

function ea_url($url) {
    $url = trim(str_replace(array("\0", "\r", "\n"), '', (string)$url));
    if ($url === '') return '';
    if (preg_match('/^(javascript|data|vbscript|file):/i', $url)) return '';
    if (substr($url,0,2) === '//') return '';
    if (preg_match('/^https?:\/\//i', $url) || preg_match('/^mailto:/i', $url) || preg_match('/^tel:/i', $url)) return $url;
    if (substr($url,0,1) === '/' || strpos($url, '../') !== false) return '';
    $clean = preg_replace('/[^A-Za-z0-9._~:\/?#\[\]@!$&\'()*+,;=% -]/', '', $url);
    return $clean === null ? '' : $clean;
}

function ea_parse_txt($path) {
    $out = array('config'=>array(), 'links'=>array(), 'footer_links'=>array(), 'overrides'=>array());
    if (!is_readable($path)) return $out;
    $lines = @file($path, FILE_IGNORE_NEW_LINES);
    if (!is_array($lines)) return $out;
    $currentItem = null;
    foreach ($lines as $raw) {
        $line = ea_clean_line($raw);
        if ($line === '' || strpos($line, ':') === false) continue;
        $partsKV = explode(':', $line, 2);
        $key = strtoupper(trim($partsKV[0]));
        $value = trim($partsKV[1]);
        if ($key === 'ITEM') {
            $slug = ea_safe_slug($value);
            $currentItem = $slug !== '' ? $slug : null;
            if ($currentItem && !isset($out['overrides'][$currentItem])) $out['overrides'][$currentItem] = array();
            continue;
        }
        if ($key === 'LINK' || $key === 'FOOTER_LINK') {
            $p = explode('|', $value, 2);
            if (count($p) === 2) {
                $label = trim($p[0]);
                $url = ea_url(trim($p[1]));
                if ($label !== '' && $url !== '') {
                    if ($key === 'LINK') $out['links'][] = array('text'=>$label, 'url'=>$url);
                    else $out['footer_links'][] = array('text'=>$label, 'url'=>$url);
                }
            }
            continue;
        }
        if ($currentItem && in_array($key, array('TITLE','DESCRIPTION','TAGS','STATUS','CREDITS','LINK'), true)) {
            $out['overrides'][$currentItem][$key] = $value;
            continue;
        }
        $currentItem = null;
        $out['config'][$key] = $value;
    }
    return $out;
}

function ea_parse_meta($path) {
    $out = array();
    if (!is_readable($path)) return $out;
    $lines = @file($path, FILE_IGNORE_NEW_LINES);
    if (!is_array($lines)) return $out;
    foreach ($lines as $raw) {
        $line = ea_clean_line($raw);
        if ($line === '' || strpos($line, ':') === false) continue;
        $p = explode(':', $line, 2);
        $out[strtoupper(trim($p[0]))] = trim($p[1]);
    }
    return $out;
}

function ea_apply_case($title, $case) {
    $case = strtolower(trim((string)$case));
    if ($case === 'uppercase') return strtoupper($title);
    if ($case === 'lowercase') return strtolower($title);
    if ($case === 'capitalize') return ucwords(strtolower($title));
    return $title;
}

function ea_format_size($bytes) {
    $units = array('B','KB','MB','GB','TB');
    $size = max(0, (int)$bytes); $i = 0;
    while ($size >= 1024 && $i < count($units)-1) { $size = $size / 1024; $i++; }
    return ($i === 0 ? (string)$size : number_format($size, 1)) . ' ' . $units[$i];
}

function ea_ext($name, $isDir) {
    if ($isDir) return 'folder';
    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    return $ext !== '' ? $ext : 'file';
}

function ea_font($font) {
    $font = strtolower(trim((string)$font));
    if ($font === 'sans') return 'Arial, Helvetica, sans-serif';
    if ($font === 'mono') return 'Courier New, Courier, monospace';
    return 'Georgia, Times New Roman, Times, serif';
}

function ea_theme($theme, $accent) {
    $accent = trim((string)$accent);
    if (!preg_match('/^#[0-9a-fA-F]{3,8}$/', $accent)) $accent = '#c8ff00';
    $theme = strtolower(trim((string)$theme));
    if ($theme === 'black') $t = array('#050505', '#f5f5f5', '#aaa', '#222');
    elseif ($theme === 'paper') $t = array('#fbf7ed', '#050505', '#6f675f', '#ded6c7');
    else $t = array('#fff', '#050505', '#696969', '#e7e7e7');
    return ':root{--bg:'.$t[0].';--fg:'.$t[1].';--muted:'.$t[2].';--line:'.$t[3].';--accent:'.$accent.';}';
}

$autoTitle = ea_human_title(basename($ROOT));
$DEFAULTS = array(
    'SITE_TITLE'=>$autoTitle,
    'SITE_DESCRIPTION'=>'A minimal archive of folders and files.',
    'LANGUAGE'=>'en',
    'HEADER_TITLE'=>$autoTitle,
    'HEADER_TEXT'=>'',
    'SHOW_FOLDERS'=>'true',
    'SHOW_FILES'=>'true',
    'SORT'=>'folders_first',
    'EXCLUDE'=>'index.php, index.html, page.txt, page.example.txt, project.txt, project.example.txt, README.md, readme.md, preview.html, test-report.txt, .htaccess, robots.txt, favicon.ico, index_assets, _private, .DS_Store',
    'MAX_ITEMS'=>'2000',
    'STYLE'=>'minimal',
    'FONT'=>'serif',
    'THEME'=>'white',
    'ACCENT_COLOR'=>'#c8ff00',
    'SHOW_ITEM_NUMBERS'=>'true',
    'ITEM_TITLE_CASE'=>'normal',
    'SHOW_DESCRIPTIONS'=>'true',
    'SHOW_TAGS'=>'true',
    'SHOW_STATUS'=>'true',
    'SHOW_CREDITS'=>'false',
    'SHOW_DATES'=>'false',
    'SHOW_SIZE'=>'false',
    'SHOW_EXTENSIONS'=>'false',
    'OPEN_LABEL'=>'Open',
    'SHOW_SEARCH'=>'true',
    'SEARCH_PLACEHOLDER'=>'Search',
    'FOOTER_TEXT'=>'© '.date('Y'),
    'FOOTER_CREDITS'=>''
);

$parsed = ea_parse_txt($ROOT . DIRECTORY_SEPARATOR . 'page.txt');
$config = array_merge($DEFAULTS, $parsed['config']);
$excludeList = array_map('trim', explode(',', (string)$config['EXCLUDE']));
$exclude = array(); foreach ($excludeList as $e) { if ($e !== '') $exclude[$e] = true; }
$maxItems = (int)$config['MAX_ITEMS']; if ($maxItems < 1) $maxItems = 1; if ($maxItems > 10000) $maxItems = 10000;
$items = array();
$scan = @scandir($ROOT);
if (!is_array($scan)) $scan = array();
foreach ($scan as $entry) {
    if (count($items) >= $maxItems) break;
    if ($entry === '.' || $entry === '..' || substr($entry,0,1) === '.') continue;
    if (isset($exclude[$entry])) continue;
    $path = $ROOT . DIRECTORY_SEPARATOR . $entry;
    if (is_link($path)) continue;
    $isDir = is_dir($path);
    $isFile = is_file($path);
    if (!$isDir && !$isFile) continue;
    if ($isDir && !ea_bool($config['SHOW_FOLDERS'])) continue;
    if ($isFile && !ea_bool($config['SHOW_FILES'])) continue;
    $slug = ea_safe_slug($entry); if ($slug === '') continue;
    $meta = $isDir ? ea_parse_meta($path . DIRECTORY_SEPARATOR . 'project.txt') : array();
    if (isset($parsed['overrides'][$slug])) $meta = array_merge($meta, $parsed['overrides'][$slug]);
    $generatedLink = $isDir ? rawurlencode($entry).'/' : rawurlencode($entry);
    $customLink = isset($meta['LINK']) ? ea_url($meta['LINK']) : '';
    $title = isset($meta['TITLE']) && trim($meta['TITLE']) !== '' ? $meta['TITLE'] : ea_human_title($entry);
    $items[] = array(
        'name'=>$entry,
        'type'=>$isDir ? 'folder' : 'file',
        'title'=>ea_apply_case($title, $config['ITEM_TITLE_CASE']),
        'description'=>isset($meta['DESCRIPTION']) ? trim($meta['DESCRIPTION']) : '',
        'tags'=>isset($meta['TAGS']) ? array_filter(array_map('trim', explode(',', $meta['TAGS']))) : array(),
        'status'=>isset($meta['STATUS']) ? trim($meta['STATUS']) : '',
        'credits'=>isset($meta['CREDITS']) ? trim($meta['CREDITS']) : '',
        'link'=>$customLink !== '' ? $customLink : $generatedLink,
        'mtime'=>@filemtime($path) ? @filemtime($path) : 0,
        'size'=>$isFile && @filesize($path) ? @filesize($path) : 0,
        'ext'=>ea_ext($entry, $isDir)
    );
}

$sort = strtolower(trim($config['SORT']));
usort($items, function($a, $b) use ($sort) {
    $title = strnatcasecmp($a['title'], $b['title']);
    if ($sort === 'files_first' && $a['type'] !== $b['type']) return $a['type'] === 'file' ? -1 : 1;
    if ($sort === 'folders_first' && $a['type'] !== $b['type']) return $a['type'] === 'folder' ? -1 : 1;
    if ($sort === 'title_desc') return strnatcasecmp($b['title'], $a['title']);
    if ($sort === 'date_newest') return ($b['mtime'] == $a['mtime']) ? $title : (($b['mtime'] > $a['mtime']) ? 1 : -1);
    if ($sort === 'date_oldest') return ($a['mtime'] == $b['mtime']) ? $title : (($a['mtime'] > $b['mtime']) ? 1 : -1);
    return $title;
});

$lang = preg_match('/^[a-z]{2}(-[A-Z]{2})?$/', (string)$config['LANGUAGE']) ? $config['LANGUAGE'] : 'en';
$style = strtolower($config['STYLE']); if (!in_array($style, array('minimal','compact','table'), true)) $style = 'minimal';
?><!doctype html>
<html lang="<?php echo ea_escape($lang); ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?php echo ea_escape($config['SITE_TITLE']); ?></title>
<meta name="description" content="<?php echo ea_escape($config['SITE_DESCRIPTION']); ?>">
<style>
<?php echo ea_theme($config['THEME'], $config['ACCENT_COLOR']); ?>
*{box-sizing:border-box}html{background:var(--bg);color:var(--fg)}body{margin:0;font-family:<?php echo ea_escape(ea_font($config['FONT'])); ?>;font-size:18px;line-height:1.42;-webkit-font-smoothing:antialiased;text-rendering:optimizeLegibility}.wrap{width:min(900px,calc(100% - 34px));margin:0 auto;padding:48px 0 28px}header{border-bottom:1px solid var(--line);padding-bottom:22px;margin-bottom:20px}.top{display:flex;justify-content:space-between;gap:22px;align-items:flex-start}.brand h1{font:inherit;font-size:clamp(38px,7vw,68px);line-height:.95;margin:0 0 10px;font-weight:400;letter-spacing:-.055em}.brand p{margin:0;color:var(--muted);max-width:650px}.links{display:flex;gap:12px;flex-wrap:wrap;justify-content:flex-end;font-size:15px}.links a,.open,footer a{color:var(--fg);text-decoration:none;border-bottom:2px solid var(--accent)}.links a:hover,.open:hover,footer a:hover{background:var(--accent);color:#000}.tools{display:flex;justify-content:space-between;align-items:center;gap:18px;margin-bottom:14px}.count{font-size:14px;color:var(--muted)}.search{width:min(260px,100%);border:0;border-bottom:1px solid var(--line);background:transparent;color:var(--fg);font:inherit;font-size:16px;padding:7px 0;outline:none}.search:focus{border-bottom-color:var(--fg)}.archive{border-top:1px solid var(--line)}.item{display:grid;grid-template-columns:48px 1fr auto;gap:14px;padding:13px 0;border-bottom:1px solid var(--line);align-items:start}.num{font-size:14px;color:var(--muted);font-variant-numeric:tabular-nums;padding-top:3px}.title{font:inherit;font-size:22px;line-height:1.1;margin:0;font-weight:400;letter-spacing:-.025em}.desc{margin:5px 0 0;color:var(--muted);font-size:16px;max-width:680px}.meta{display:flex;gap:8px;flex-wrap:wrap;margin-top:7px;color:var(--muted);font-size:13px}.pill{border:1px solid var(--line);padding:1px 6px}.type{background:var(--accent);color:#000;border-color:var(--accent)}.open{font-size:15px;white-space:nowrap}.empty{padding:24px 0;color:var(--muted);display:none}footer{margin-top:30px;padding-top:16px;border-top:1px solid var(--line);color:var(--muted);font-size:14px;display:flex;justify-content:space-between;gap:16px;flex-wrap:wrap}.compact .item{grid-template-columns:42px 1fr auto;padding:9px 0}.compact .title{font-size:18px}.compact .desc,.compact .meta{display:none}.table .archive{display:table;width:100%;border-collapse:collapse}.table .item{display:table-row}.table .num,.table .item-main,.table .open{display:table-cell;border-bottom:1px solid var(--line);padding:10px 8px;vertical-align:top}.table .desc{display:none}@media(max-width:640px){body{font-size:17px}.wrap{width:min(100% - 26px,900px);padding-top:34px}.top,.tools{display:block}.links{justify-content:flex-start;margin-top:16px}.search{width:100%;margin-top:12px}.item{grid-template-columns:38px 1fr}.open{grid-column:2}.brand h1{font-size:46px}}
</style>
</head>
<body class="<?php echo ea_escape($style); ?>">
<div class="wrap">
<header><div class="top"><div class="brand"><h1><?php echo ea_escape($config['HEADER_TITLE']); ?></h1><?php if (trim($config['HEADER_TEXT']) !== '') { ?><p><?php echo ea_escape($config['HEADER_TEXT']); ?></p><?php } ?></div><?php if (!empty($parsed['links'])) { ?><nav class="links" aria-label="Primary links"><?php foreach ($parsed['links'] as $l) { ?><a href="<?php echo ea_escape($l['url']); ?>"><?php echo ea_escape($l['text']); ?></a><?php } ?></nav><?php } ?></div></header>
<main><div class="tools"><div class="count"><span id="visibleCount"><?php echo count($items); ?></span> / <?php echo count($items); ?> items</div><?php if (ea_bool($config['SHOW_SEARCH'])) { ?><input id="search" class="search" type="search" placeholder="<?php echo ea_escape($config['SEARCH_PLACEHOLDER']); ?>" autocomplete="off"><?php } ?></div>
<section class="archive" id="archive">
<?php foreach ($items as $i => $item) { $searchText = strtolower($item['title'].' '.$item['description'].' '.implode(' ', $item['tags']).' '.$item['status'].' '.$item['ext'].' '.$item['type']); ?>
<article class="item" data-search="<?php echo ea_escape($searchText); ?>">
<?php if (ea_bool($config['SHOW_ITEM_NUMBERS'])) { ?><div class="num"><?php echo str_pad((string)($i+1), 2, '0', STR_PAD_LEFT); ?></div><?php } else { ?><div></div><?php } ?>
<div class="item-main"><h2 class="title"><?php echo ea_escape($item['title']); ?></h2><?php if (ea_bool($config['SHOW_DESCRIPTIONS']) && $item['description'] !== '') { ?><p class="desc"><?php echo ea_escape($item['description']); ?></p><?php } ?><div class="meta"><span class="pill type"><?php echo ea_escape($item['type']); ?></span><?php if (ea_bool($config['SHOW_EXTENSIONS'])) { ?><span class="pill"><?php echo ea_escape($item['ext']); ?></span><?php } ?><?php if (ea_bool($config['SHOW_STATUS']) && $item['status'] !== '') { ?><span class="pill"><?php echo ea_escape($item['status']); ?></span><?php } ?><?php if (ea_bool($config['SHOW_DATES']) && $item['mtime']) { ?><span><?php echo ea_escape(date('Y-m-d', (int)$item['mtime'])); ?></span><?php } ?><?php if (ea_bool($config['SHOW_SIZE']) && $item['size']) { ?><span><?php echo ea_escape(ea_format_size($item['size'])); ?></span><?php } ?><?php if (ea_bool($config['SHOW_CREDITS']) && $item['credits'] !== '') { ?><span><?php echo ea_escape($item['credits']); ?></span><?php } ?><?php if (ea_bool($config['SHOW_TAGS'])) { foreach ($item['tags'] as $tag) { ?><span>#<?php echo ea_escape($tag); ?></span><?php } } ?></div></div><a class="open" href="<?php echo ea_escape($item['link']); ?>"><?php echo ea_escape($config['OPEN_LABEL']); ?> →</a></article>
<?php } ?>
</section><div class="empty" id="empty">No items found.</div></main>
<footer><div><?php echo ea_escape(trim($config['FOOTER_TEXT'] . ($config['FOOTER_CREDITS'] !== '' ? ' · '.$config['FOOTER_CREDITS'] : ''))); ?></div><?php if (!empty($parsed['footer_links'])) { ?><div><?php foreach ($parsed['footer_links'] as $l) { ?><a href="<?php echo ea_escape($l['url']); ?>"><?php echo ea_escape($l['text']); ?></a> <?php } ?></div><?php } ?><div><?php echo ea_escape($VERSION); ?></div></footer>
</div><script>(function(){var input=document.getElementById('search');var items=[].slice.call(document.querySelectorAll('.item'));var count=document.getElementById('visibleCount');var empty=document.getElementById('empty');if(!input)return;input.oninput=function(){var q=this.value.replace(/^\s+|\s+$/g,'').toLowerCase();var visible=0;items.forEach(function(item){var ok=!q||item.getAttribute('data-search').indexOf(q)!==-1;item.style.display=ok?'':'none';if(ok)visible++;});count.innerHTML=String(visible);empty.style.display=visible?'none':'block';};})();</script></body></html>
